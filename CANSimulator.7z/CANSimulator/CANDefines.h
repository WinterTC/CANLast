#ifndef CANDEFINES_H
#define CANDEFINES_H
#include <QVector>
#include <QString>
/*Byte order*/
typedef enum {
    E_CANIntelBitOrder_Sequential = 0,
    E_CANIntelBitOrder_Standard
}E_CANIntelBitOrder;

typedef enum {
    E_CANMotoBitOrder_ForwardLSB,
    E_CANMotoBitOrder_ForwardMSB,
    E_CANMotoBitOrder_Sequential,
    E_CANMotoBitOrder_Backward
}E_CANMotoBitOrder;

typedef enum {
    E_CANByteOrder_Intel = 0,
    E_CANByteOrder_Motorola = 1,
}E_CANByteOrder;
/*End Byte order*/

/*type*/
typedef enum {
    E_CANSignalType_Signed=0,
    E_CANSignalType_UnSigned,
    E_CANSignalType_Float,
    E_CANSignalType_Double,
}E_CANSignalType;
/*End type*/

/*ID type*/
typedef enum {
    E_CANMsgIDType_Standard=0,
    E_CANMsgIDType_Extended
}E_CANMsgIDType;
/*End ID type*/

/*union value in different types*/
typedef union{
    long long lValue;
    unsigned long long uValue;
    float fValue;
    double dValue;
}U_CANValue;
/*End union value in different types*/

/*Wave form*/
typedef enum{
    E_CANSignalWaveForm_None=0,
    E_CANSignalWaveForm_Sine,
    E_CANSignalWaveForm_Square
}E_CANSignalWaveForm;
/*End Wave form*/

typedef struct  CANSignal{
    QString m_Name; // signal names
    QString m_Comment; // signal comments
    unsigned char m_Length; //length in bit
    E_CANByteOrder m_ByteOrder;
    E_CANSignalType m_ValueType;
    U_CANValue m_InitValue;
    double m_Factor;
    double m_Offset;
    double m_Min;
    double m_Max;
#ifdef __cplusplus
    CANSignal(){
        m_Factor=1.0;
        m_Offset=0;
        m_Min=0;
        m_Max=0;
        m_ByteOrder = E_CANByteOrder_Intel;
        m_ValueType = E_CANSignalType_Signed;
        m_Length = 8;
    }
#endif
}CANSignal;

typedef struct CANSignalInMessage{
    unsigned char m_StartBit;
    CANSignal m_Signal;
#ifdef __cplusplus
    CANSignalInMessage(){
        m_StartBit = 0;
    }
#endif
}CANSignalInMessage;

typedef struct CANMessage{
    QString m_Name; // signal names
    QString m_Comment; // signal comments
    unsigned char m_Length; //length in byte
    unsigned int m_ID;
    E_CANMsgIDType m_IdType;
    QVector<CANSignalInMessage> m_Signals;
#ifdef __cplusplus
    CANMessage(){
        m_Length = 8;
        m_IdType = E_CANMsgIDType_Standard;
        m_Signals.clear();
        m_ID = 0;
    }
#endif
}CANMessage;

#endif // CANDEFINES_H
