#include "utilities.h"
#include <math.h>
#include <QDebug>

CANSignalSimulate::CANSignalSimulate()
{
    m_WaveForm =  E_CANSignalWaveForm_None;
    m_WaveUsed = false;
    m_StartBit = 0;
    m_Value.uValue = 0;
//    m_WaveFormProperties.m_Sine.m_Amplitude = m_CANSign.m_Max - m_CANSign.m_Min ;
//    m_WaveFormProperties.m_Sine.m_Amplitude = m_CANSign.m_Max - m_CANSign.m_Min ;
}
void CANSignalSimulate::pack(unsigned char * data /*byte array of message*/,
                             unsigned char length /*Length in byte of message*/,
                             unsigned long long timestamp)
{
    /*Step 1:  Calculate signal value = m_Value / resolution + offset*/

    switch (this->m_CANSign.m_ByteOrder) {
    case E_CANByteOrder_Intel:
        /* data[0|1|2|3|4|5|6|7]
 * Intel: LSB first
*/
        /*Step 2: pack calculate value into data[]*/
        break;
    case E_CANByteOrder_Motorola:
        /* data[0|1|2|3|4|5|6|7]
 * Intel: MSB first
*/
        /*Step 2: pack calculate value into data[]*/
        break;
    default:
        break;
    }
}
void CANSignalSimulate::unpack(unsigned char * data, unsigned char length){
    /*For transmit and receive*/


    switch (this->m_CANSign.m_ByteOrder) {
    case E_CANByteOrder_Intel:
        /* data[0|1|2|3|4|5|6|7]
 * Intel: LSB first
*/

        /*Step 1: unpack signal value from data[]*/
        break;
    case E_CANByteOrder_Motorola:
        /* data[0|1|2|3|4|5|6|7]
 * Intel: MSB first
*/
        /*Step 1: unpack signal value from data[]*/
        break;
    default:
        break;
    }
    /*Step 2:  m_Value = signal value * resolution + offset*/
}

U_CANValue CANSignalSimulate::to_signal_value(unsigned long long timestamp){
    U_CANValue ret;
    switch (m_WaveForm) {
    case E_CANSignalWaveForm_Sine:
        ret.dValue = m_WaveFormProperties.m_Sine.m_Amplitude * sin(2*PI/m_WaveFormProperties.m_Sine.m_Cycle * timestamp + PI*m_WaveFormProperties.m_Sine.m_Phase/180.0) + m_WaveFormProperties.m_Sine.m_Offset;
        break;
    case E_CANSignalWaveForm_Square:
        ret.dValue = timestamp%(m_WaveFormProperties.m_Square.m_CycleH + m_WaveFormProperties.m_Square.m_CycleL) <= m_WaveFormProperties.m_Square.m_CycleH ?
                    m_WaveFormProperties.m_Square.m_PeakH:
                    m_WaveFormProperties.m_Square.m_PeakL;
    default:
        ret.dValue = m_Value.dValue;
        break;
    }
    ret.dValue = ret.dValue/m_CANSign.m_Factor + m_CANSign.m_Offset;
    switch (m_CANSign.m_ValueType) {
    case E_CANSignalType_Signed:
        ret.lValue = ( long long)round(ret.dValue);  // get integer part
        break;
    case E_CANSignalType_UnSigned:
        ret.uValue = (unsigned long long)round(ret.dValue); // get integer part
        break;
    case E_CANSignalType_Float:
        ret.fValue = (float)ret.dValue;
        break;
    case E_CANSignalType_Double:
        break;
    default:
        break;
    }
    return ret;
}

U_CANValue CANSignalSimulate::to_signal_value(double phy_value)
{
    U_CANValue ret;
    // raw value = physical value * resolution + offset
    ret.dValue =  phy_value / this->m_CANSign.m_Factor + this->m_CANSign.m_Offset;
    switch (m_CANSign.m_ValueType) {
    case E_CANSignalType_Signed:
        ret.lValue = (long long)ret.dValue;
        if(ret.lValue<0){
            ret.lValue = 0 - ret.lValue;
            ret.lValue | (1<<m_CANSign.m_Length-1);
        }else{

        }
//        for(int i=63;i>m_CANSign.m_Length;i--){
//            ret.lValue&=(~(1<<i));
//        }
        break;
    case E_CANSignalType_UnSigned:
        ret.uValue = (unsigned long long)ret.dValue;
        break;
    case E_CANSignalType_Float:
        ret.fValue = (float)ret.dValue;
        break;
    case E_CANSignalType_Double:
        break;
    default:
        break;
    }
    return ret;
}

double CANSignalSimulate::to_physical_value(unsigned long long value /*Raw value*/){
    U_CANValue ret;
    unsigned long long mask = 1,tmp ;
    ret.uValue = value;
    switch (m_CANSign.m_ValueType) {
    case E_CANSignalType_Signed:
        mask = mask << (m_CANSign.m_Length-1);
        tmp = mask & value;
        if(tmp != 0){
            value = value & (~mask);//remove signed bit
            ret.uValue = 0-value;
        }else{
            ret.uValue = value;
        }
        ret.dValue = ret.lValue;
        break;
    case E_CANSignalType_UnSigned:
        ret.dValue = ret.uValue;
        break;
    case E_CANSignalType_Float:
        ret.dValue = ret.fValue;
        break;
    case E_CANSignalType_Double:
        break;
    default:
        break;
    }
    ret.dValue = ret.dValue * m_CANSign.m_Factor + m_CANSign.m_Offset;
    return ret.dValue;
}

void CANSignalSimulate::pack_intel(unsigned char * data, unsigned char startbit, unsigned char bitcount, unsigned long long  value)
{
    unsigned char shift;
    while (bitcount > 0) {
        shift = startbit % 8;
        /* Clear the bits to write. */
        data[startbit / 8] &= ~(((1 << bitcount) - 1) << shift);
        /* Set the bits to write. */
        data[startbit / 8] |= (((1 << bitcount) - 1) & value) << shift;
        /* Get the next bit position. */
        bitcount -= 8 - shift;
        startbit += 8 - shift;
        /* Remove the currently written part of value. */
        value >>= 8 - shift;
    }
}

void CANSignalSimulate::pack_motorola(unsigned char * data, unsigned char startbit, unsigned char bitcount, unsigned long long  value)
{
    unsigned char bits;

    while (bitcount > 0) {
        /* Get the number of bits to work on. */
        bits = startbit % 8 + 1;
        bits = bits < bitcount ? bits : bitcount;
        /* Clear the bits to write. */
        data[startbit / 8] &= ~(((1 << bits) - 1) << (startbit % 8 + 1 - bits));
        /* Set the bits to write. */
        data[startbit / 8] |= (((1 << bitcount) - 1) & value) >> (bitcount - bits) << (startbit % 8 + 1 - bits);
        /* Get the next bit position. */
        bitcount -= bits;
        startbit = (startbit & ~(0x07)) + 15;
    }
}

unsigned long long CANSignalSimulate::unpack_intel(unsigned char  const * data, bool sign,unsigned char startbit, unsigned char bitcount )
{
    ulong value = 0;
    uchar shift = 0;
    while (bitcount > 0) {
        /* Get the bottommost part of the value. */
        value |= ((data[startbit / 8] >> (startbit % 8)) & ((1ul << bitcount) - 1)) << shift;
        /* Update counters. */
        bitcount -= 8 - (startbit % 8);
        shift += 8 - (startbit % 8);
        startbit += 8 - (startbit % 8);
    }

    if (sign && (value >> (shift + bitcount - 1))) {
        return ((~0ul) << (shift + bitcount)) | value;
    }
    return value;

}

unsigned long long CANSignalSimulate::unpack_motorola(unsigned char  const * data, bool sign,unsigned char startbit, unsigned char bitcount )
{

}

void CANMessageSimulate::pack(unsigned long long timestamp)
{
    //pack all signals
    m_Data[0] =0xDE;
}

void CANMessageSimulate::packall()
{
    m_Data[0] =0xAD;
}

void CANMessageSimulate::unpack()
{
    //unpack all signals
}

void CANSimulatorDatabaseAssosiate::addDbPath(const QString & path){

}

void CANSimulatorDatabaseAssosiate::removeDbPath(const QString & path)
{

}

CANMessageSimulate  CANSimulatorDatabaseAssosiate::getMessageById(unsigned int id, unsigned char len)
{
    foreach (const CANMessageSimulate & msg, m_Messages) {
       if(msg.m_Id == id && len==msg.m_Len){
            return msg;
       }
    }
    return CANMessageSimulate();
}

void CANSimulatorDatabaseAssosiate::test(){
    CANMessageSimulate newMsg;
    CANSignalSimulate newSignal;

    newSignal.m_StartBit = 1;
    newSignal.m_Value.dValue = 1.5;
    newSignal.m_CANSign.m_Factor = 0.5;
    newSignal.m_CANSign.m_ByteOrder = E_CANByteOrder_Intel;
    newSignal.m_CANSign.m_Length = 8;
    newSignal.m_CANSign.m_Max = 10;
    newSignal.m_CANSign.m_Min =-10;
    newSignal.m_CANSign.m_ValueType = E_CANSignalType_Signed;
    newSignal.m_CANSign.m_Name = QString("SPEED");
    newSignal.m_WaveForm = E_CANSignalWaveForm_None;
    newMsg.m_CANSignals.append(newSignal);

    newSignal.m_CANSign.m_Length = 4;
    newSignal.m_CANSign.m_Factor = -0.5;
    newSignal.m_CANSign.m_Name = QString("STATUS");
    newMsg.m_CANSignals.append(newSignal);

    newMsg.m_Channel = 1;
    newMsg.m_Direction = E_Direction_Rx;
    newMsg.m_DbPath = "ECU1.dbc";
    newMsg.m_Name = "ENGINE";
    newMsg.m_Id = 0x300;
    newMsg.m_isReqToTx = false;
    newMsg.m_Len = 8;
    m_Paths.append(QString("ECU1.dbc"));    
    m_Messages.append(newMsg);


    newMsg.m_Len = 4;

    newMsg.m_CANSignals.clear();

    newSignal.m_CANSign.m_Length = 4;
    newSignal.m_CANSign.m_Name = QString("LEFT-TOP");
    newMsg.m_CANSignals.append(newSignal);

    newSignal.m_CANSign.m_Length = 4;
    newSignal.m_CANSign.m_Name = QString("LEFT-REAR");
    newMsg.m_CANSignals.append(newSignal);

    newSignal.m_CANSign.m_Length = 4;
    newSignal.m_CANSign.m_Name = QString("RIGHT-TOP");
    newMsg.m_CANSignals.append(newSignal);

    newSignal.m_CANSign.m_Length = 4;
    newSignal.m_CANSign.m_Name = QString("RIGHT-REAR");
    newMsg.m_CANSignals.append(newSignal);

    newMsg.m_Channel = 2;
    newMsg.m_Direction = E_Direction_Tx;
    newMsg.m_DbPath = "ECU1.dbc";
    newMsg.m_Name = "APA";
    newMsg.m_Id = 0x301;
    m_Messages.append(newMsg);

}

const CANMessageSimulate &  CANSimulatorDatabaseAssosiate::getMessagesInfo(const QString &path,const QString &msgName)
{
    foreach (const CANMessageSimulate & msg, m_Messages) {
        if(msg.m_DbPath == path &&
                msg.m_Name == msgName){
            return msg;
        }
    }
    return CANMessageSimulate();
}

ULongLongSpinBox::ULongLongSpinBox(QWidget * parent)
:   QAbstractSpinBox(parent)
,   m_min(std::numeric_limits<qulonglong>::min())
,   m_max(std::numeric_limits<qulonglong>::max())
,   m_step(1)
,   m_value(m_min)
, m_base(10)
{
    setInputMethodHints(Qt::ImhDigitsOnly);

    connect(this, &QAbstractSpinBox::editingFinished,
            this, &ULongLongSpinBox::onEditingFinished);
}

void ULongLongSpinBox::fixup(QString & input) const
{
    input.remove(locale().groupSeparator());
}

void ULongLongSpinBox::stepBy(int steps)
{
    setValue(m_value + steps * m_step);
}

QValidator::State ULongLongSpinBox::validate(QString & input, int & pos) const
{
    QValidator::State state;
    validateAndInterpret(input, pos, state);
    return state;
}

qulonglong ULongLongSpinBox::value() const
{
    return m_value;
}

void ULongLongSpinBox::setValue(qulonglong value)
{
    qulonglong clampedValue = std::min(m_max, std::max(value, m_min));

    if (clampedValue == m_value)
        return;

    m_value = clampedValue;
    lineEdit()->setText(textFromValue(m_value));
    emit valueChanged(m_value);
}

qulonglong ULongLongSpinBox::minimum() const
{
    return m_min;
}

void ULongLongSpinBox::setMinimum(qulonglong minimum)
{
    m_min = minimum;

    if (m_max < m_min)
        m_max = m_min;
}

qulonglong ULongLongSpinBox::maximum() const
{
    return m_max;
}

void ULongLongSpinBox::setMaximum(qulonglong maximum)
{
    m_max = maximum;

    if (m_min > m_max)
        m_min = m_max;
}

qulonglong ULongLongSpinBox::step() const
{
    return m_step;
}

void ULongLongSpinBox::setStep(qulonglong step)
{
    m_step = step;
}

void ULongLongSpinBox::setRange(
    qulonglong min,
    qulonglong max)
{
    setMinimum(min);
    setMaximum(max);
}

void ULongLongSpinBox::onEditingFinished()
{
//    qDebug()<<"edit finish";
    qulonglong value = valueFromText(text());

    qulonglong clampedValue = std::min(m_max, std::max(value, m_min));

    if (clampedValue == m_value)
    {
        return;
    }
    m_value = clampedValue;
    emit valueChanged(m_value);
}

QAbstractSpinBox::StepEnabled ULongLongSpinBox::stepEnabled() const
{
    StepEnabled enabled;

    if (m_value > m_min)
        enabled |= QAbstractSpinBox::StepDownEnabled;

    if (m_value < m_max)
        enabled |= QAbstractSpinBox::StepUpEnabled;

    return enabled;
}

QString ULongLongSpinBox::textFromValue(qulonglong value)
{
    QString str;

//    str = locale().toString(value,
//                            );

//    if (value >= 1000)
//        str.remove(locale().groupSeparator());
    str=QString::number(value,m_base).toUpper();
    return str;
}

qulonglong ULongLongSpinBox::valueFromText(const QString & text)
{
    int pos = lineEdit()->cursorPosition();
    QValidator::State state = QValidator::Acceptable;
    return validateAndInterpret(text, pos, state);
}

qulonglong ULongLongSpinBox::validateAndInterpret(
    const QString & input,
    int & /*pos*/,
    QValidator::State & state) const
{
    qulonglong num = m_min;
//    qDebug()<<"Input"<< input;
    if (input.isEmpty() || input == QLatin1String("+"))
    {
        state = QValidator::Intermediate;
    }
    else if (input.startsWith(QLatin1String("-")))
    {
        state = QValidator::Invalid;
    }
    else
    {
        bool ok = false;

        //Check base
        num =  input.toULongLong(&ok,m_base);
#if 0
        if (!ok && input.contains(locale().groupSeparator()) && m_max >= 1000)
        {
            QString copy = input;
            copy.remove(locale().groupSeparator());
            num = locale().toULongLong(copy, &ok);
        }
#endif
        if (!ok)
            state = QValidator::Invalid;
        else if (num >= m_min && num <= m_max)
            state = QValidator::Acceptable;
        else if (num > m_max)
            state = QValidator::Invalid;
        else
            state = QValidator::Intermediate;
    }

    if (state != QValidator::Acceptable)
        num = m_min;

    return num;
}

void ULongLongSpinBox::setBase(int base)
{
    m_base = base;
}
