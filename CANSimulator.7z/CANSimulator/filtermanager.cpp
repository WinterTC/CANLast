#include "filtermanager.h"
#include "ui_filtermanager.h"
#include <QMessageBox>
#include <QCheckBox>
#include <QComboBox>
#include <QJsonArray>
#include <QJsonValue>
#include <QJsonObject>

FilterManagerWindow::FilterManagerWindow(QWidget *parent, bool filterStop, const QVector<FilterData> & filter, CANSimulatorDatabaseAssosiate * assosiateDb) :
    QMainWindow(parent),
    m_Filters(filter),
    m_AssisiateDatabase(assosiateDb)
{
    setupUi(this);
    m_TableFilter->horizontalHeader()->setDefaultAlignment(Qt::AlignLeft);
    m_StopFilter = filterStop;
    m_StopFilterCheck->setChecked(filterStop);
    connect(this,SIGNAL(destroyed()),this, SLOT(deleteLater()));
    connect(m_OkButton,SIGNAL(released()),this,SLOT(slotOKButton()));
    connect(m_CancelButton,SIGNAL(released()),this,SLOT(slotCancelButton()));
    connect(m_InsertRangeButton,SIGNAL(released()),this,SLOT(slotInsertRangeButton()));
    connect(m_InsertMessageButton,SIGNAL(released()),this,SLOT(slotInsertMessageButton()));
    connect(m_RemoveButton,SIGNAL(released()),this,SLOT(slotRemoveButton()));
    drawFilterData();
}

FilterManagerWindow::~FilterManagerWindow()
{
}

void FilterManagerWindow::addFilter(FilterData & newFilter)
{

}

void FilterManagerWindow::slotOKButton(){
    qDebug()<< "Ok button" << m_StopFilterCheck->isChecked();
    //Emit signal to FilterManager
    emit signalSaveFilter(m_StopFilterCheck->isChecked(),m_Filters);
    close();
}

void FilterManagerWindow::slotCancelButton()
{
    close();
}

void FilterManagerWindow::slotInsertRangeButton()
{
    //Open an message box and take data inside

    FilterData newData;
    FilterInsertDialog * dialog= new  FilterInsertDialog(NULL,&newData);
    if(dialog->exec() == QDialog::Accepted){
        qDebug()<< newData.m_StartID << newData.m_EndID;
        if(newData.m_StartID==0||
                newData.m_EndID ==0||
                newData.m_StartID > newData.m_EndID )
        {
            QMessageBox::critical(this, "Insert filter fail", "The Identifier must be a Hex number\n start ID must be less than end ID",
                                  QMessageBox::Ok);
        }else{
            m_Filters.append(newData);
            drawFilterData();
        }
        //TODO: Insert new item in table
    }else{

    }

}

void FilterManagerWindow::slotInsertMessageButton()
{
    QVector<FilterData> newData;
    FilterInsertMessageDialog dialog(this,m_AssisiateDatabase,&newData);
    dialog.exec();
    if(newData.size()>0){
        foreach (FilterData filter, newData) {
            m_Filters.append(filter);
        }
        drawFilterData();
    }
}

void FilterManagerWindow::slotRemoveButton()
{
    // get current item and remove
    int row = m_TableFilter->currentRow();
    if(row>=0){
        m_TableFilter->removeRow(row);
        m_Filters.removeAt(row);
    }
}

void FilterManagerWindow::drawFilterData()
{
    /*Create data for widget*/

    while(m_TableFilter->rowCount()>0){
        m_TableFilter->removeRow(0);
    }
    int i = 0;
    m_TableFilter->setRowCount(m_Filters.size());
    QTableWidgetItem * item =NULL;
    QCheckBox * checkBox=NULL;
    QComboBox * combo = NULL;
    QString tmpString;
    QStringList CANChannels;
    CANChannels << "CAN" << "CAN1" <<"CAN2";
    foreach (FilterData filter, m_Filters) {
        switch (filter.m_Type) {
        case E_FilterType_CANMessage:

            item = new QTableWidgetItem(filter.m_DbName);
            item->setFlags((Qt::ItemFlags)(~Qt::ItemIsEditable) & Qt::ItemIsEnabled);
            m_TableFilter->setItem(i,0,item);

            item = new QTableWidgetItem(filter.m_Name);
            item->setFlags((Qt::ItemFlags)(~Qt::ItemIsEditable) & Qt::ItemIsEnabled);
            m_TableFilter->setItem(i,1,item);

            item = new QTableWidgetItem();
            item->setData(Qt::DisplayRole,QVariant(filter.m_StartID));
            item->setFlags((Qt::ItemFlags)(~Qt::ItemIsEditable) & Qt::ItemIsEnabled);
            m_TableFilter->setItem(i,2,item);

            item = new QTableWidgetItem("CAN-Message");
            item->setFlags((Qt::ItemFlags)(~Qt::ItemIsEditable) & Qt::ItemIsEnabled);
            m_TableFilter->setItem(i,3,item);

            break;
        case  E_FilterType_CANRange:

            item = new QTableWidgetItem();
            item->setFlags((Qt::ItemFlags)(~Qt::ItemIsEditable) & Qt::ItemIsEnabled);
            m_TableFilter->setItem(i,0,item);

            item = new QTableWidgetItem();
            item->setFlags((Qt::ItemFlags)(~Qt::ItemIsEditable) & Qt::ItemIsEnabled);
            m_TableFilter->setItem(i,1,item);

            tmpString.clear();
            tmpString.append(QString::number((unsigned long)filter.m_StartID));
            tmpString.append(" - ");
            tmpString.append(QString::number((unsigned long)filter.m_EndID));
            item = new QTableWidgetItem(tmpString);
            item->setFlags((Qt::ItemFlags)(~Qt::ItemIsEditable) & Qt::ItemIsEnabled);
            m_TableFilter->setItem(i,2,item);

            item = new QTableWidgetItem("CAN-Range");
            item->setFlags((Qt::ItemFlags)(~Qt::ItemIsEditable) & Qt::ItemIsEnabled);
            m_TableFilter->setItem(i,3,item);

            break;
        case  E_FilterType_ErrFrame:
            item = new QTableWidgetItem();
            item->setFlags((Qt::ItemFlags)(~Qt::ItemIsEditable) & Qt::ItemIsEnabled);
            m_TableFilter->setItem(i,0,item);

            item = new QTableWidgetItem();
            item->setFlags((Qt::ItemFlags)(~Qt::ItemIsEditable) & Qt::ItemIsEnabled);
            m_TableFilter->setItem(i,1,item);

            item = new QTableWidgetItem();
            item->setFlags((Qt::ItemFlags)(~Qt::ItemIsEditable) & Qt::ItemIsEnabled);
            m_TableFilter->setItem(i,2,item);

            item = new QTableWidgetItem("CAN-ErrorFrame");
            item->setFlags((Qt::ItemFlags)(~Qt::ItemIsEditable) & Qt::ItemIsEnabled);
            m_TableFilter->setItem(i,3,item);

            break;

        default:
            break;
        }

        checkBox  = new QCheckBox(m_TableFilter);
        checkBox->setChecked(filter.m_Rx);
        m_TableFilter->setCellWidget(i,5,checkBox);

        checkBox  = new QCheckBox(m_TableFilter);
        checkBox->setChecked(filter.m_Tx);
        m_TableFilter->setCellWidget(i,6,checkBox);

        checkBox  = new QCheckBox(m_TableFilter);
        checkBox->setChecked(filter.m_TxRq);
        m_TableFilter->setCellWidget(i,7,checkBox);

        checkBox  = new QCheckBox(m_TableFilter);
        checkBox->setChecked(filter.m_RTRData);
        m_TableFilter->setCellWidget(i,8,checkBox);

        checkBox  = new QCheckBox(m_TableFilter);
        checkBox->setChecked(filter.m_RTRRemote);
        m_TableFilter->setCellWidget(i,9,checkBox);

        combo = new QComboBox(this);
        combo->addItems(CANChannels);
        combo->setCurrentIndex(filter.m_Channels);
        m_TableFilter->setCellWidget(i,4,combo);
        i++;

    }

}

bool FilterNodeManager::process(MeasureSetupMessageCommon * message){
    if(!message) return false;
    bool __matching=false;
    if(message->getMessageType() != E_MsgDataID_CANMsg){
        //Forwarding to next hops
        return true;
    }
    MeasureSetupMessageCAN * __MsgCAN = static_cast<MeasureSetupMessageCAN*>(message);
    foreach (FilterData filter, m_Filters) {
        //Check direction
        if((__MsgCAN->getMessageInfo().m_Direction == E_Direction_Rx && filter.m_Rx == true)||
                (__MsgCAN->getMessageInfo().m_Direction == E_Direction_Tx && filter.m_Tx == true)    ){
            __matching = false;
        }
        //check ID
        if(__MsgCAN->getMessageInfo().m_Id & (~0x80000000) < filter.m_StartID ||
                __MsgCAN->getMessageInfo().m_Id & (~0x80000000) > filter.m_EndID ||
                ((__MsgCAN->getMessageInfo().m_Id & 0x80000000 != 0) != filter.m_isExtended )
                ){
            __matching = false;
        }

//        if(__matching != m_StopFilter){
//            //1. Not match & stop --> pass
//            //2. match & pass --> pass
//            return true;
//        }
//        __matching=true;
    }

    return (__matching == m_StopFilter);
}

void FilterNodeManager::loadConfig(const QJsonValue & config){
    //load config from Json node
    m_Filters.clear();
    /*
    {
        "type":"FILTER",
        "AFTER":1,
        "name": "PF",
        "stop": false,
        "data":[
            {"startId":111,"endId":222, "Tx":true, "Rx":true , "channels":"0"}
        ]
    }
*/
    if(config.isObject()){

        QJsonObject obj = config.toObject();

        if(obj.isEmpty()) return;

        QJsonValue tmpValue = obj["name"];
        if(tmpValue.isString()){
            setName(tmpValue.toString());
        }
        tmpValue = obj["stop"];
        if(tmpValue.isBool()){
            m_StopFilter = tmpValue.toBool();
        }

        tmpValue = obj["data"];
        if(tmpValue.isArray()){
            FilterData newData;
            foreach (const QJsonValue & value, tmpValue.toArray()) {
                qDebug()<< value;
                if(value.isObject()){                    
                    qDebug()<<value.toObject()["kind"].toInt();
                    switch (value.toObject()["kind"].toInt()) {
                    case 1:
                        //This is an CAN-range filter
                        newData.m_Tx = value.toObject()["Tx"].toBool();
                        newData.m_Rx = value.toObject()["Rx"].toBool();
                        newData.m_RTRData = value.toObject()["RTRData"].toBool();
                        newData.m_RTRRemote = value.toObject()["RTRRemote"].toBool();
                        newData.m_Channels = value.toObject()["channels"].toInt();
                        newData.m_StartID = value.toObject()["startId"].toInt();
                        newData.m_EndID = value.toObject()["endId"].toInt();
                        newData.m_Type=E_FilterType_CANRange;
                        m_Filters.append(newData);
                        break;
                    case 2:
                        //This is an CAN-message filter
                        newData.m_Tx = value.toObject()["Tx"].toBool();
                        newData.m_Rx = value.toObject()["Rx"].toBool();
                        newData.m_RTRData = value.toObject()["RTRData"].toBool();
                        newData.m_DbName = value.toObject()["database"].toString();
                        newData.m_Name = value.toObject()["name"].toString();
                        newData.m_RTRRemote = value.toObject()["RTRRemote"].toBool();
                        newData.m_Channels = value.toObject()["channels"].toInt();
                        newData.m_StartID = value.toObject()["id"].toInt();
                        newData.m_Type=E_FilterType_CANMessage;
                        m_Filters.append(newData);
                        break;
                    case 3:
                        //This is an CAN-message filter
                        newData.m_Tx = value.toObject()["Tx"].toBool();
                        newData.m_Rx = value.toObject()["Rx"].toBool();
                        newData.m_RTRData = value.toObject()["RTRData"].toBool();
                        newData.m_RTRRemote = value.toObject()["RTRRemote"].toBool();
                        newData.m_Channels = value.toObject()["channels"].toInt();
                        newData.m_Type=E_FilterType_ErrFrame;
                        m_Filters.append(newData);

                        break;
                    default:
                        break;
                    }
                }
            }
            qDebug()<<m_Filters.size();
        }
    }
}

const QJsonValue FilterNodeManager::saveConfig(){
    //Save config to an Json node
    QJsonObject filterProp, filterObj;
    QJsonArray filtersArray;

    filterProp["name"] = QJsonValue(QString("SF"));
    filterProp["type"] = QJsonValue(QString("FILTER"));
    filterProp["stop"] = QJsonValue(m_StopFilter);
    foreach (FilterData filter, m_Filters) {
        switch (filter.m_Type) {
        case E_FilterType_CANRange:
            filterObj["Tx"] = QJsonValue(filter.m_Tx);
            filterObj["Rx"] = QJsonValue(filter.m_Rx);
            filterObj["RTRData"] = QJsonValue(filter.m_RTRData);
            filterObj["RTRRemote"] = QJsonValue(filter.m_RTRRemote);
            filterObj["channels"] = QJsonValue((int)filter.m_Channels);
            filterObj["startId"] = QJsonValue((int)filter.m_StartID);
            filterObj["endId"] = QJsonValue((int)filter.m_EndID);
            filterObj["kind"] = QJsonValue((int)filter.m_Type);
            filtersArray.append(filterObj);
            break;
        case E_FilterType_CANMessage:
            filterObj["Tx"] = QJsonValue(filter.m_Tx);
            filterObj["Rx"] = QJsonValue(filter.m_Rx);
            filterObj["RTRData"] = QJsonValue(filter.m_RTRData);
            filterObj["RTRRemote"] = QJsonValue(filter.m_RTRRemote);
            filterObj["channels"] = QJsonValue((int)filter.m_Channels);
            filterObj["id"] = QJsonValue((int)filter.m_StartID);
            filterObj["database"] = QJsonValue(filter.m_DbName);
            filterObj["name"] = QJsonValue(filter.m_DbName);
            filterObj["kind"] = QJsonValue((int)filter.m_Type);
            filtersArray.append(filterObj);
            break;
        case E_FilterType_ErrFrame:
            filterObj["Tx"] = QJsonValue(filter.m_Tx);
            filterObj["Rx"] = QJsonValue(filter.m_Rx);
            filterObj["RTRData"] = QJsonValue(filter.m_RTRData);
            filterObj["RTRRemote"] = QJsonValue(filter.m_RTRRemote);
            filterObj["channels"] = QJsonValue((int)filter.m_Channels);
            filterObj["kind"] = QJsonValue((int)filter.m_Type);
            filtersArray.append(filterObj);
            break;
        default:
            break;
        }
    }
    filterProp["data"] = filtersArray;
//    qDebug() << filterProp;
    return filterProp;
}

FilterInsertMessageDialog::FilterInsertMessageDialog(QWidget * parent ,CANSimulatorDatabaseAssosiate * AssosiateDb,QVector<FilterData> * rspData):
    QDialog(parent),
    m_rspFilterData(rspData),
    m_AssosiateDb(AssosiateDb)
{
    setupUi(this);
    m_treeWidget->expandAll();

    QStringList paths= m_AssosiateDb->getDbPath();
    QTreeWidgetItem * itemFile, * itemMsgHeader, *itemMsg;
    foreach (QString path, paths) {

        itemFile= new  QTreeWidgetItem();
        itemMsgHeader = new  QTreeWidgetItem();

        itemFile->setData(0,Qt::DisplayRole,path);
        itemFile->setIcon(0,QIcon(":/icons/connection.png"));

        itemMsgHeader->setData(0,Qt::DisplayRole,"Messages");
        itemMsgHeader->setIcon(0,QIcon(":/icons/message.png"));

        itemFile->addChild(itemMsgHeader);

        foreach (CANMessageSimulate msg, m_AssosiateDb->getMessagesInfo()) {
            itemMsg = new  QTreeWidgetItem();
            itemMsg->setData(0,Qt::DisplayRole,msg.m_Name);
            itemMsg->setData(0,Qt::UserRole,msg.m_Id);
            itemMsg->setIcon(0,QIcon(":/icons/message.png"));
            itemMsgHeader->addChild(itemMsg);
        }
        itemMsgHeader = new  QTreeWidgetItem();
        itemMsgHeader->setData(0,Qt::DisplayRole,"Node");
        itemMsgHeader->setIcon(0,QIcon(":/icons/cannode.png"));
        itemFile->addChild(itemMsgHeader);

        m_treeWidget->insertTopLevelItem(m_treeWidget->topLevelItemCount(),itemFile);
    }
    m_treeWidget->expandAll();
}
void FilterInsertMessageDialog::slotSearchButton()
{

}

void FilterInsertMessageDialog::accept(){ //overwrite
    QTreeWidgetItem * currentItem = m_treeWidget->currentItem();
    QTreeWidgetItem * parent;
    if(currentItem && currentItem->childCount() == 0){
        parent = currentItem->parent();
        if(parent && parent->data(0,Qt::DisplayRole) == QVariant("Messages")){
            parent = parent->parent();
            FilterData rspData;
            rspData.m_DbName = parent->data(0,Qt::DisplayRole).toString();
            rspData.m_Name = currentItem->data(0,Qt::DisplayRole).toString();
            rspData.m_Type = E_FilterType_CANMessage;
            rspData.m_StartID = currentItem->data(0,Qt::UserRole).toUInt();
            if(m_rspFilterData){
                m_rspFilterData->append(rspData);
            }
        }else         if(parent && parent->data(0,Qt::DisplayRole) == QVariant("Events")){
            parent = parent->parent();
            FilterData rspData;
            rspData.m_Name = currentItem->data(0,Qt::DisplayRole).toString();
            rspData.m_Comment = QString("CAN Errorframe");
            rspData.m_Type = E_FilterType_ErrFrame;
            if(m_rspFilterData){
                m_rspFilterData->append(rspData);
            }
        }
    }
    QDialog::accept();

}
